function toggleMobileNavbar() {
  document.getElementById("nav-links-container").classList.toggle("active");
}


