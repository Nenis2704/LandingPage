document.getElementById("boton-enviar").addEventListener("click", function(event) {
  event.preventDefault(); // Evita el envío del formulario
  let isValid = true;

  let email = document.getElementById("email");
  let uemailError = document.getElementById("emailError");

  if (validarCorreo(email.value)) {
    emailError.style.display = "none";
  } else {
    emailError.style.display = "block";
    isValid = false;
  }

  if (isValid) {
      alert("Correo de recuperacion enviado.");
  }

});

function validarCorreo(email) {
  const regex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return regex.test(email);
}
