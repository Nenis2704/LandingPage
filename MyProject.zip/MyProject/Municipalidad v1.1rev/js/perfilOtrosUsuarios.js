// Si reutilizas la misma función de menú móvil:
function toggleMobileNavbar() {
    const navLinks = document.getElementById('nav-links-container');
    navLinks.classList.toggle('active');
  }
  
  // Ejemplo de placeholders a modo de "carga" (opcional):
  window.addEventListener('DOMContentLoaded', () => {
    // Podrías inyectar datos dinámicamente a las tablas
    // simulando fetch a tu base de datos, etc.
    // Por ahora se deja la tabla con placeholders
    console.log('Página de Perfil de Otros Usuarios cargada.');
  });  

// //Iniciar sesion
// const loginButton = document.getElementById('iniciarSesionButton');
// if (loginButton) {
//   loginButton.addEventListener("click", function() {
//     window.location.href = "/Municipalidad v1.1rev/login.html";
//   });
// }