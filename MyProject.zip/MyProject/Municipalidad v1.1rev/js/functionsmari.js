function toggleMobilebarraNav() {
  document.getElementById("nav-links-container").classList.toggle("active");
}

/*const buttons = document.querySelectorAll(".tarjeta");
buttons.forEach((button) => {
  button.addEventListener("click", function () {
    let perfil = this.dataset.perfil; // Obtiene el perfil (admin o customer)

    // Si el perfil es "customer", va a "customer/descripcion.html"
    // Si es "admin" (o cualquier otro valor), va a "admin/d-0003.html"
    let ruta = perfil === "customer" ? "customer/descripcioncustomer.html" : "admin/descripcionadmin.html";

    // Redirige a la ruta correspondiente
    window.location.href = `/perfiles/${ruta}`;
  });
});*/


//Iniciar sesion
const loginButton = document.getElementById('iniciarSesionButton');
if (loginButton) {
  loginButton.addEventListener("click", function() {
    window.location.href = "/Municipalidad v1.1rev/login.html";
  });
}
const loginButton2 = document.getElementById('iniciarSesionButton2');
if (loginButton2) {
  loginButton2.addEventListener("click", function() {
    window.location.href = "/Municipalidad v1.1rev/login.html";
  });
}
