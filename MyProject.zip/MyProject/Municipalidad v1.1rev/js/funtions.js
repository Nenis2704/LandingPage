function toggleMobileNavbar() {
  document.getElementById("nav-links-container").classList.toggle("active");
}

const buttons = document.querySelectorAll(".card");
buttons.forEach((button) => {
  // const ruta = button.dataset.ruta;
  button.addEventListener("click", function () {
    window.location.href = "/Municipalidad v1.1rev/perfiles/admin/d-0003.html";
  // window.location.href = `/perfiles/admin/${ruta}`;
  });
});

//Iniciar sesion
const loginButton = document.getElementById('iniciarSesionButton');
if (loginButton) {
  loginButton.addEventListener("click", function() {
    window.location.href = "/Municipalidad v1.1rev/login.html";
  });
}

const loginButton2 = document.getElementById('iniciarSesionButton2');
if (loginButton2) {
  loginButton2.addEventListener("click", function() {
    window.location.href = "/Municipalidad v1.1rev/login.html";
  });
}
