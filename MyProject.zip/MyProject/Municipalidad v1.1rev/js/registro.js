document.getElementById("loginButton").addEventListener("click", function(event) {
    event.preventDefault(); // Evita que el botón haga refresh
    let isValid = true;

    // Obtener valores de los inputs
    let nombre = document.getElementById("nombre").value.trim();
    let apellido1 = document.getElementById("apellido1").value.trim();
    let apellido2 = document.getElementById("apellido2").value.trim();
    let email = document.getElementById("email").value.trim();
    let cedula = document.getElementById("cedula").value.trim();
    let numeroTelefono = document.getElementById("numeroTelefono").value.trim();
    let distrito = document.getElementById("distritoRegistro").value.trim();
    let direccion = document.getElementById("direccion").value.trim();
    let password1 = document.getElementById("password1").value.trim();
    let password2 = document.getElementById("password2").value.trim();

    // Mensajes de error
    let nombreError = document.getElementById("nombreError");
    let apellido1Error = document.getElementById("apellido1Error");
    let apellido2Error = document.getElementById("apellido2Error");
    let emailError = document.getElementById("emailError");
    let cedulaError = document.getElementById("cedulaError");
    let numeroTelefonoError = document.getElementById("numeroTelefonoError");
    let pass1Error = document.getElementById("pass1Error");
    let pass2Error = document.getElementById("pass2Error");


    // Validación de la contraseña (mínimo 6 caracteres)
    if (password1.length < 6) {
        pass1Error.style.display = "block";
        isValid = false;
    } else {
        pass1Error.style.display = "none";
    }

    if (password1 != password2) {
      pass2Error.style.display = "block";
      isValid = false;
    } else {
      pass2Error.style.display = "none";
    }

    if (nombre.length > 3) {
      nombreError.style.display = "none";
    } else {
      nombreError.style.display = "block";
      isValid = false;
    }

    if (apellido1.length > 3) {
      apellido1Error.style.display = "none";
    } else {
      apellido1Error.style.display = "block";
      isValid = false;
    }

    if (apellido2.length > 3) {
      apellido2Error.style.display = "none";
    } else {
      apellido2Error.style.display = "block";
      isValid = false;
    }

    if (cedula.length == 9) {
      cedulaError.style.display = "none";
    } else {
      cedulaError.style.display = "block";
      isValid = false;
    }

    if (numeroTelefono.length == 8) {
      numeroTelefonoError.style.display = "none";
    } else {
      numeroTelefonoError.style.display = "block";
      isValid = false;
    }

    if (direccion.length > 5) {
      direccionError.style.display = "none";
    } else {
      direccionError.style.display = "block";
      isValid = false;
    }

    // Validacion del email
    if (validarCorreo(email)) {
      emailError.style.display = "none";
    } else {
      emailError.style.display = "block";
      isValid = false;
    }

    // Si todo es válido, mostramos un mensaje
    if (isValid) {
        alert("Registro exitoso.");
    }
});

function validarCorreo(email) {
  const regex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return regex.test(email);
}
