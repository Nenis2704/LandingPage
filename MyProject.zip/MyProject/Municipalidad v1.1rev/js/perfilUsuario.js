// Mostrar/ocultar menú móvil (si no usas un machote.js aparte)
function toggleMobileNavbar() {
  document.getElementById('nav-links-container').classList.toggle('active');
}

/**
 * Muestra la ventana emergente de edición con transición (0.8s).
 */
function mostrarVentanaEditar() {
  // Agrega la clase .active para que el overlay haga su transición de opacidad
  const overlay = document.getElementById('overlayEditarPerfil');
  overlay.classList.add('active');
}

/**
 * Cierra la ventana emergente de edición.
 */
function cerrarVentanaEditar() {
  const overlay = document.getElementById('overlayEditarPerfil');
  overlay.classList.remove('active');
}

/**
 * Validaciones (Nombre >=3, Apellidos >=3, Cédula 9-15, Distrito => en las opciones).
 * Se simula guardado.
 */
const formularioEditarPerfil = document.getElementById('formEditarPerfilId');
formularioEditarPerfil.addEventListener('submit', (e) => {
  e.preventDefault();

  // 1) Validar Nombre
  const nombreVal = document.getElementById('nombreForm').value.trim();
  if (nombreVal.length < 3) {
    alert('El nombre debe tener al menos 3 caracteres.');
    return;
  }

  // 2) Validar Apellidos
  const apellidosVal = document.getElementById('apellidosForm').value.trim();
  if (apellidosVal.length < 3) {
    alert('Los apellidos deben tener al menos 3 caracteres.');
    return;
  }

  // 3) Validar Cédula (9 a 15 caracteres)
  const cedulaVal = document.getElementById('cedulaForm').value.trim();
  if (cedulaVal.length < 9 || cedulaVal.length > 15) {
    alert('La cédula debe tener entre 9 y 15 caracteres.');
    return;
  }

  // 4) Validar Distrito
  const distritoVal = document.getElementById('distritoForm').value;
  const distritosPermitidos = ['Sabanilla', 'Mercedes', 'San Pedro', 'San Rafael'];
  if (!distritosPermitidos.includes(distritoVal)) {
    alert('Distrito no válido.');
    return;
  }

  // Si pasa todas las validaciones, simulamos guardado
  alert('Datos guardados correctamente (simulación).');
  cerrarVentanaEditar();
});

/**
 * Mostrar rol sólo si Admin o Concejo
 */
window.addEventListener('DOMContentLoaded', () => {
  let userRol = 'Concejo de Distrito';
  // let userRol = 'Administrador';
  // let userRol = 'Usuario';

  const rolParrafo = document.getElementById('rolUsuario');
  if (userRol === 'Administrador' || userRol === 'Concejo de Distrito') {
    rolParrafo.textContent = userRol;
    rolParrafo.style.display = 'block';
  }
});
