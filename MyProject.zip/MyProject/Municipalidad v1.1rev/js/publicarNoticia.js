// Función de validación del form
function validarFormularioNoticia() {
    // Obtener los valores de los campos
    const titulo = document.getElementById('TituloFormNoticia').value.trim();
    const contenidoNoticia = document.getElementById('contenidoFormNoticia').value.trim();
  
    // Comprobar si alguno de los campos está vacío
    if (titulo.length === 0 || contenidoNoticia.length === 0) {
      alert("El título y el contenido de la noticia son obligatorios.");
      return false;
    }else{
    return true;
  }
}
  
  // Asociar la función de validación al evento de envío del formulario
  document.getElementById('publicarNoticiaForm').addEventListener('submit', function(event) {
    if (!validarFormularioNoticia()) {
      event.preventDefault(); // Prevenir el envío si la validación falla
    }
  });
  


//contador placeholder contenidoNoticia
document.addEventListener("DOMContentLoaded", function () {
    const textarea = document.getElementById("contenidoFormNoticia");
    const contador = document.getElementById("contadorNoticia");
    const maxCaracteres = textarea.maxLength;

    function actualizarContador() {
        let caracteresUsados = textarea.value.length;
        let caracteresRestantes = maxCaracteres - caracteresUsados;

        // Actualiza el texto del contador
        contador.textContent = caracteresRestantes + " caracteres restantes.";
    }

    // Inicializa el contador al cargar la página
    actualizarContador();

    // Escucha el evento input para actualizar en tiempo real
    textarea.addEventListener("input", actualizarContador);
});

//button Cancelar
function cancelarEnvio() {
    const rutaDefault = "landing.html";
    window.location.href = rutaDefault;
  }
  
  // Asociar la función cancelar al evento de clic del botón Cancelar
  document.getElementById('cancelar').addEventListener('click', function(event) {
    event.preventDefault(); // Evitar que el formulario se envíe si se hace clic en Cancelar
    cancelarEnvio();    // Llamar a la función cancelarFormulario
  });