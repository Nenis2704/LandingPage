//Iniciar sesion
const loginButton = document.getElementById('iniciarSesionButton');
if (loginButton) {
  loginButton.addEventListener("click", function() {
    window.location.href = "/Municipalidad v1.1/login.html";
  });
}