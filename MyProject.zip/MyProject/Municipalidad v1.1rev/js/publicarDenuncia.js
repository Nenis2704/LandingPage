function validarFormularioDenuncia() {
    const titulo = document.getElementById('TituloFormDenuncia').value.trim();
    const contenidoDenuncia = document.getElementById('contenidoFormDenuncia').value.trim();
    const siCheckbox = document.getElementById("si");
    const noCheckbox = document.getElementById("no");

    //Campos
    if (titulo.length === 0 || contenidoDenuncia.length === 0) {
        alert("Todos los campos son obligatorios.");
        return false;
    }

    //Checkbox
    if (!siCheckbox.checked && !noCheckbox.checked) {
        alert("Debes seleccionar una opción en los checkboxes.");
        return false;
    }

    return true;
}

//Enviar
document.getElementById('enviarDenunciaForm').addEventListener('submit', function(event) {
    if (!validarFormularioDenuncia()) {
        event.preventDefault(); 
    }
});

document.addEventListener("DOMContentLoaded", function() {
    const siCheckbox = document.getElementById("si");
    const noCheckbox = document.getElementById("no");

    function toggleCheckbox() {
        if (siCheckbox.checked) {
            noCheckbox.checked = false;
        } else if (noCheckbox.checked) {
            siCheckbox.checked = false;
        }
    }
    noCheckbox.addEventListener("change", toggleCheckbox);
    siCheckbox.addEventListener("change", toggleCheckbox);
});

// Contador
document.addEventListener("DOMContentLoaded", function () {
    const textarea = document.getElementById("contenidoFormDenuncia");
    const contador = document.getElementById("contadorDenuncia");
    const maxCaracteres = textarea.maxLength;

    function actualizarContador() {
        let caracteresUsados = textarea.value.length;
        let caracteresRestantes = maxCaracteres - caracteresUsados;
        contador.textContent = caracteresRestantes + " caracteres restantes.";
    }
    actualizarContador();

    textarea.addEventListener("input", actualizarContador);
});

// Button Cancelar
function cancelarEnvio() {
    const rutaDefault = "landing.html";
    window.location.href = rutaDefault;
}

document.getElementById('cancelar').addEventListener('click', function(event) {
    event.preventDefault();
    cancelarEnvio();  
});